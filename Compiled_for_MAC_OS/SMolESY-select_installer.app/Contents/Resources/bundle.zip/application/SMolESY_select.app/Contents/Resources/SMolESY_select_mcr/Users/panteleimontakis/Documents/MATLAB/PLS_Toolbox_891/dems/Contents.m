% Demonstration scripts and files for PLS_Toolbox.

